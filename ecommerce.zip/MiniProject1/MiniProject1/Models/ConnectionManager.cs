﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using MiniProject1.Models;

namespace MiniProject1.Models
{
    public class ConnectionManager
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        public bool InsertUpdateDelete(string command)
        {
            SqlCommand cmd = new SqlCommand(command, con);
            if (ConnectionState.Closed == con.State)
                con.Open();
            return (cmd.ExecuteNonQuery() > 0) ? true : false;
        }
        public DataTable GetRecords(string command)
        {
            SqlDataAdapter da = new SqlDataAdapter(command, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}