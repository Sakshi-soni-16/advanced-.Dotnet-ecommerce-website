﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using MiniProject1.Models;

namespace MiniProject1.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/
        ConnectionManager cm = new ConnectionManager();
        public ActionResult Index1()
        {
            if (Session["aid"] != null)
            {

            }
            else {
                Response.Write("<script>alert('first login');window.location.href='/Home/Signin1'</script>");
            }
            return View();
        }

        [HttpGet]
        public ActionResult AddProduct()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddProduct( FormCollection frm)
        {
            string pname = frm["pname"];
            HttpPostedFileBase file = Request.Files["ppic"];
            if (file != null)
            {
                string command = "insert into Add_Product values('" + pname + "','" + int.Parse(frm["pprice"]) + "','" + int.Parse(frm["offer"]) + "','" + int.Parse(frm["offprice"]) + "','" + frm["category"] + "','" + file.FileName + "','" + frm["descript"] + "','" + DateTime.Now + "')";
                if (cm.InsertUpdateDelete(command) == true)
                {
                    file.SaveAs(Server.MapPath("../Content/product/"+ file.FileName));
                    Response.Write("<script>alert('new product uploaded successfully')</script>");
                }
                else {
                    Response.Write("<script>alert('product not uploaded')</script>");
                }
            }
            else {
                Response.Write("<script>alert('plz upload picture of product')</script>");
            }
            return View();
        }
        public ActionResult changepassword()
        {
            return View();
        }
        public ActionResult order()
        {
            return View();
        }
        public ActionResult contact()
        {
            return View();
        }
        public ActionResult product()
        {

            return View();
        }
        public void Logout()
        {
            Session.Abandon(); // expire of current session
        }
        public ActionResult ForgetPassword()
        {
            return View();
        }
        public ActionResult EnterOTP()
        {
            return View();
        }

        public ActionResult Details(int id)
        {
            string command = "select*from Tbl_order where oid='" + id + "'";
            ConnectionManager cm = new ConnectionManager();
            System.Data.DataTable dt = cm.GetRecords(command);
            string pname = dt.Rows[0]["pname"].ToString();
            string price = dt.Rows[0]["price"].ToString();
            string pic= dt.Rows[0]["pics"].ToString();
            string[] pnames = pname.Split(',');
            string[] prices = price.Split(',');
            string[] pics = pic.Split(',');
            string tr = "";
         
            for (int i = 0; i < pnames.Length; i++)
            {
                tr = tr + "<tr><td>" + (i + 1) + "</td><td>" + pnames[i] + "</td><td>" + prices[i] + "</td><td><img src='../" + pics[i] + "' height='70px' width='70px'/></td></tr>";
            }
            ViewBag.tr = tr;
                return View();
        }
        public void Delete(int Id)
        {
            string command = "delete from Tbl_order where oid='" + Id + "'";
            ConnectionManager cm = new ConnectionManager();
            System.Data.DataTable dt = cm.GetRecords(command);
            if (cm.InsertUpdateDelete(command))
            {
                Response.Write("<script>alert('Record  delete');window.location.href='/Admin/order'</script>");
            }
            else
            {
                Response.Write("<script>alert('Record not delete');window.location.href='/Admin/order'</script>");

            }
        }
      

    }
}
