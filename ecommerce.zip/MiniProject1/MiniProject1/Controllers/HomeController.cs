﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MiniProject1.Models;

namespace MiniProject1.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
      
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Signin1()
        {

            return View();
        }
        public ActionResult Checkout()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Checkout(string pname,string price,string pic,string uname,string mob,string email,string haddr,string oaddr)
        {
            string command = "insert into Tbl_order values('" + pname + "','" + price + "','" + pic + "','" + uname + "','" + mob + "','" + email + "','" + haddr + "','" + oaddr + "','" + DateTime.Now.ToString() + "',0)";
            ConnectionManager cm = new ConnectionManager();
            if (cm.InsertUpdateDelete(command) == true)
            {
                Response.Write("<script>alert('thanks for order,we recieved your order');window.location.href='/Home/Index'</script>");
            }
            else {
                Response.Write("<script>alert('something went wrong')</script>");
            }
            return View();
        }
        [HttpPost]
        public ActionResult Signin1(string aid, string passwd)
        {
            string command = " select * from Login where adminid='" + aid + "' and password='" + passwd + "' and status=1";
            ConnectionManager cm= new ConnectionManager();
            System.Data.DataTable dt=cm.GetRecords(command);
            if(dt.Rows.Count>0)
            {
            int lcount=int.Parse(dt.Rows[0]["LCount"].ToString());
                lcount=lcount+1;
                //set session 
                Session["aid"] = aid;
                Response.Write("<script>alert('welcome to admin zone');window.location.href='/Admin/Index1'</script>");
            }
            else{
            Response.Write("<script>alert('invalid userid and password')</script>");
            }
            return View();
        }

    }
}
